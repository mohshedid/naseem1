{
	'name': 'Theme for Product Form', 
	'description': 'Manage Theme for Product Form', 
	'author': 'Muhammad Kamran', 
	'depends': ['base','sale','product','mrp'], 
	'application': True,
	'data': [
	'views/template.xml',
	'views/product_code.xml'
	],
}