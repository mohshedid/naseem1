# -*- coding: utf-8 -*-
{
    'name': "Ajax Login Integration",
    'description': "Ajax Login Integration",
    'author': 'Muhammad Kamran',
    'application': True,
    'depends': ['base_setup','web','website'],
    'data': [
	    'views/template.xml'
	 	],
}