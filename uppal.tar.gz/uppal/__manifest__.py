# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

{
    'name': 'Uppal',
    'author': 'BCUBE',
    'summary': 'Uppal',
    'website': 'bcube.pk',
    'version': '1',
    'depends': ['base','sale','purchase'],
    'data': [
        'templates.xml',
    ],
    'installable': True,
    'auto_install': False
}
